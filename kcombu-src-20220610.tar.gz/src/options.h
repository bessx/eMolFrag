/*

 <options.h>

*/

extern void Set_Default_Global_PAR();
extern int Set_Global_PAR_from_OPTION_VALUE();
extern void Show_Option_Help_MCS();
extern char* Get_Date_String();
extern int    Get_Time_in_Second();
extern double Get_Time_in_Second_by_Double();
extern void Set_END_DATE();
