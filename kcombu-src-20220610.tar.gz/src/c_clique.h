/*

 <c_clique.h>
 
*/

extern int C_clique_BronKerbosch_Version1();
extern int C_clique_Cazals_Karande();
extern void Evaluate_Connected_Degree_of_Atom_Pair();
