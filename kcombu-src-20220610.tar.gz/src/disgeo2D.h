/*
  <disgeo2D.h>
*/

extern int set_XY_to_UNIT_by_distance_geometry();
extern float restraint_energy_with_derivative();
extern float restraint_energy();
