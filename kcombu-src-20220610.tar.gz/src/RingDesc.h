/*
 
<RingDesc.h> 

*/

extern void Set_Ring_Descriptor();
extern void show_ring_descriptor();
extern float similarity_bwn_ring_descriptors();
extern float similarity_bwn_oneatom_ring_descriptors();
extern int Number_of_ring_block_type();
