/*

 <MOLECULE_from_CCD_CIF.h>
 
*/

/* FUNCTIONS (GLOBAL) */
extern int Translate_Lines_into_CCD_CIF_Molecule();
