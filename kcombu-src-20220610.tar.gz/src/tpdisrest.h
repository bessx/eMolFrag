/*

< tpdisrest.h >

*/

extern void setup_variables_from_string_tpdisrest();
extern void mk_string_status_tpdisrest();
extern void mk_short_string_status_tpdisrest();
extern void Transform_MOLECULE_by_RandomChosenAtoms_Translation_Random_Rotation();
extern void Transform_MOLECULE_by_Random_3PointPairs_with_TPDISREST_restraint();
