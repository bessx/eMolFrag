/*
 
 <ioKCF.h> 
 

*/ 

extern int  Translate_Lines_into_KCF_Molecule();
extern void Write_KCF_Molecule();
extern void Get_Part_Of_Line();
