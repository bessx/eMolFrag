/*
 <2DMAP.h> 
*/ 


/*** FUNCTIONS (GLOBAL) ***/
extern int Malloc_CHAR2DMAP();
extern int Malloc_UNSIGNED_CHAR2DMAP();
extern int Malloc_FLOAT2DMAP();
extern int Malloc_INT2DMAP();
extern int Free_CHAR2DMAP();
extern int Free_UNSIGNED_CHAR2DMAP();
extern int Free_FLOAT2DMAP();
extern int Free_INT2DMAP();
extern void Write_Distance_FLOAT2DMAP_in_Phylip_format();
extern void show_conmap();
