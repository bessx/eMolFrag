>>>>> KCOMBU program <<<<< 

==============================================================================
Copyright 2018  Takeshi Kawabata.  All rights reserved.

This software is released under the three-clause BSD License, see LICENSE.txt.
==============================================================================

=========== Installation and Usage ===========

See html files under the directory 'doc/'.

=========== Citing KCOMBU program ===========

Please cite:

1) Kawabata, T. Build-up algorithm for atomic correspondence between chemical structures. J.Chem.Info.Model., 2011,51, 1775-1787. 

2) Kawabata T., Nakamura,H. 3D flexible alignment using 2D maximum common substructure: dependence of prediction accuracy on target-reference chemical similarity. J.Chem.Info.Model., 2014,54, 1850-1863.


